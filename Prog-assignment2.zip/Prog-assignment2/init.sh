chmod go-rwx -R .
/usr/bin/sed -i "s/UID/$USER/g" summary*sh