#!/bin/bash -x
#SBATCH -M notchpeak 
#SBATCH --account=owner-guest 
#SBATCH --partition=notchpeak-guest 
#SBATCH --nodes=1
#SBATCH --ntasks=1
#SBATCH -C c32
#SBATCH -t 3:00:00
#SBATCH --mail-type=ALL
#SBATCH --mail-user=u0927688@utah.edu
#SBATCH -c 16

source env.sh | tee summary1.$SLURM_JOB_ID\.log
echo "FIX: -c 1 (last SBATCH arguement)!" | tee -a summary1.$SLURM_JOB_ID\.log
echo "FIX: number of threads and number of trials below!" | tee -a summary1.$SLURM_JOB_ID\.log
./pa2-p1-sol 16 32 | tee -a summary1.$SLURM_JOB_ID\.log
