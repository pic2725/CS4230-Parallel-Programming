#include <omp.h>
void pa2_p3_sol(int n, float *__restrict__ a, float *__restrict__ b,
                float *__restrict__ c, int nThreads)
// No code modifications above here or in files pa2-p2-main.c or pa2-p2-base.c
// All code modifications go below this line in this function
{
  omp_set_num_threads(nThreads);


  int i, j, k;
  #pragma omp parallel private(j, i, k)
  {
    #pragma omp for schedule(dynamic)

    for (j = 0; j < n; j++){

      for (i = 0; i < n; i++){

        for (k = 0; k < i; k++){

          c[j * n + i] = c[j * n + i] + a[k * n + j] * b[k * n + i];
        }
      }
    }
  }
}

  // for (i = 0; i < n; i++)
  //   for (j = 0; j < n; j++)
  //     for (k = 0; k < i; k++)
  //       c[j * n + i] = c[j * n + i] + a[k * n + j] * b[k * n + i];

