#include <omp.h>
void pa2_p2_sol(int n, float *__restrict__ a, float *__restrict__ b,
                float *__restrict__ c, int nThreads)
// No code modifications above here or in files pa2-p2-main.c or pa2-p2-base.c
// All code modifications go below this line in this function
{
  omp_set_num_threads(nThreads);


  int i, j, k;

  #pragma omp parallel 
  {
    #pragma omp for private(j)
    for (j = 0; j < n; j++) {
      for (k = 0; k < n; k++) {

        for (i = 0; i < n; i++) {
          
          c[j * n + i] = c[j * n + i] + a[k * n + j] * b[k * n + i];   
        }
      } 
    }
  }
  
    
}
