#include <omp.h>
#include <stdio.h>

#include <omp.h>

void Merge(int a[], int b[], int lo, int mid, int hi);
void Merge_Sort(int a[], int b[], int lo, int hi);
void Helper(int a[], int b[], int lo, int hi, int nThreads);

void Merge_Sort_Par(int a[], int b[], int n, int nThreads) {
  omp_set_num_threads(nThreads);

  #pragma omp parallel
  #pragma omp master

  Helper(a, b, 0, n - 1, nThreads); 

}

void Helper(int a[], int b[], int lo, int hi, int nThreads) {

  if(nThreads >= 2) {
    
    #pragma omp task
    Helper(a, b, lo, (lo + hi) / 2, nThreads / 2);
    #pragma omp task
    Helper(a, b, (lo + hi) / 2 + 1, hi, nThreads / 2);
 
    #pragma omp taskwait
    Merge(a, b, lo, (lo + hi) / 2, hi);

  }
  else {
    Merge_Sort(a, b, lo, hi);
  }

    

}
