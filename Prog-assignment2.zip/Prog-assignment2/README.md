# Getting started
## Building the assignment

```bash
git clone https://gitlab.chpc.utah.edu/cs4230/assignment2.git Prog-assignment2
cd Prog-assignment2
# chpc has default read permissions for everyone, we set correct permission
bash init.sh
source env.sh
make
```

## Setting up environment
   On CHPC machines, use command `source env.sh` every time you log in
   to any machine (when you login to chpc and any time you run `srun` or
   `salloc`. For now `env.sh` sets gcc version and creates `env.log` file which
   you can share if you face problems.<br/>
   
## Correctness tests
   Makefile should create three executables for three problems and print output
   denoting performance of code and correctness of code.
   Each executable takes number of threads as command line arguement. You can
   run executable as `./pa2-p1-sol 32`. If you would like to run function multiple
   times, executables takes *optional* second argument <ntrials>. `./pa2-p1-sol 32 3`
   will run it 3 times and report max and average performance.
   You need to make sure you call `omp_set_num_threads` to make sure executable
   uses the number of threads are used as denoted on command line. See
   `nThreads` variable.
   You can use any machine you like to debug your code, note you need to make
   sure your code compiles and runs on chpc machines.
   Make changes in files which end in -sol.c. You can make changes in *-main.c
   for testing.
   > We will not consider any changes files ending with `-main.c`
   
## Performance tests
   We will use specific machines to measure the performance. Once your code is
   correct, submit performance run as:

   ```bash
   # make sure to change "-c" option (last SBATCH option) in the batch (*sh) files!
   # and pass correct program arguments to change nthreads.
   sbatch summary.p1.sh # OR sbatch summary.p2.sh sbatch summary.p3.sh depending on the problem
   ```
   ***For this assignment you can vary number of cores you used using `-c` option.***

   > Do not change `-C c32 --nodes=1` in batch files! It makes sure that everyone gets
   > same CPU.
   > Also note difference between `-C` and `-c`. The small c `-c` denotes number
   > of cores in allocation request. In above example we are asking for 16
   > cores.
   >  You can change partition/account/number of cores (on one node)/time
   > needed (`-t`).

   If you ***really*** need interactive job for performance evaluation,

   ```bash
   srun -M notchpeak --account=owner-guest --partition=notchpeak-guest --nodes=1 \
	--ntasks=1 -c 16 -C c32 -t 0:05:00  --pty /bin/bash -l
   ```

   In your submission, make sure you include `summary.*.sh` with appropriate
   `-c <numcores>` and program arguements `nthreads`.
   The `summary.*.sh` will produce `summary<problemNo>.<slurmjobID>.log`.

# Submission
  1. [ ] For each program, make sure your program works with any "N".
  2. [ ] Make sure program beats performance targets for specified "N" value in the assignment.
  3. [ ] Once you beat performance target, copy `summary<problemNumber>.$SLURM_JOB_ID.log` to `summary<problemNumber>.final.log`.\
     Command: `cp summary<problemNumber>.$SLURM_JOB_ID.log summary<problemNumber>.final.log`
  4. [ ] If you had used `summary.<problemNumber>.sh`, make sure you don't delete or change that file. You can make that file read-only.\
     Command: `chmod u-w summary.<problemNumber>.sh`\
     To make that file writable again, change `u-w` to `u+w`.
  5. [ ] Once you are done with all problems, create `report.pdf` mentioning what optimizations you did and how did those optimizations helped improve
     performance.
  6. [ ] Place `report.pdf` in `Prog-assignment2` folder.
  7. [ ] Make sure `summary.*.sh`, `summary*.final.log`, `report.pdf` are in `Prog-assignment2` folder, and `summary.*.sh` correct updates to choose appropriate number of threads.
  8. [ ] Zip the folder.\
     Command: `zip -r Prog-assignment2.zip Prog-assignment2 # Works on chpc node`
  9. [ ] Upload on canvas 🎉

# Notes
   1. If you use code hosting website including chpc's gitlab make sure you
      create private repository.
   2. If you have questions, ask in piazza under `Prog-assignment2` section.
