// Use "gcc -O3 -fopenmp" to compile

#include <math.h>
#include <omp.h>
#include <stdio.h>
#include <stdlib.h>
#include <sys/time.h>
#include <unistd.h>
#ifndef N
#define N (4001)
#endif
#define threshold (0.0000001)

// Copied from https://stackoverflow.com/a/3437484/1686377
#define min(a, b)                                                              \
  ({                                                                           \
    __typeof__(a) _a = (a);                                                    \
    __typeof__(b) _b = (b);                                                    \
    _a < _b ? _a : _b;                                                         \
  })

void compare(int n, float wref[][n], float w[][n]);
void pa2_p3_base(int n, float *__restrict__ a, float *__restrict__ b,
                 float *__restrict__ c);
void pa2_p3_sol(int n, float *__restrict__ a, float *__restrict__ b,
                float *__restrict__ c, int nThreads);

float c[N][N], b[N][N], a[N][N], cc[N][N];

int main(int argc, char *argv[]) {
  int nThreads;

#if defined(USE_OMP_TIMINGS)
#define rtclock omp_get_wtime
#else
  double rtclock(void);
#endif

  double clkbegin, clkend;
  double t1, t2;
  double t, t_min = INFINITY, t_ave, *times;

  int i, j, k;

  if (argc < 2) {
    printf("Number of threads not specified\n");
    exit(-1);
  }
  nThreads = atoi(argv[1]);
  int NTRIALS = (argc > 2) ? atoi(argv[2]) : 1;
  times = (double *)malloc(NTRIALS * sizeof(double));
  if (nThreads <= 0) {
    printf("Num threads <= 0\n");
    exit(-1);
  }
  printf("Num threads = %d\n", nThreads);
  printf("Matrix Size = %d\n", N);

  for (i = 0; i < N; i++)
    for (j = 0; j < N; j++) {
      a[i][j] = rand();
      b[i][j] = rand();
    }
  int NTrials;
  for (NTrials = 0; NTrials < NTRIALS; ++NTrials) {
    for (i = 0; i < N; i++)
      for (j = 0; j < N; j++)
        c[j][i] = 0;
    t1 = rtclock();
    pa2_p3_base(N, &a[0][0], &b[0][0], &c[0][0]);
    t2 = rtclock();
    times[NTrials] = t = (t2 - t1);
    printf("Base version: %.2f GFLOPs; Time = %.2f\n",
           1.0e-9 * N * N * (N - 1) / (t2 - t1), t2 - t1);
  }
  t_ave = 0;
  t_min = INFINITY;
  for (NTrials = 0; NTrials < NTRIALS; ++NTrials) {
    t_ave += times[NTrials];
    t_min = min(t_min, times[NTrials]);
  }
  t_ave /= NTRIALS;
  printf("Base version: %.2f GFLOPs (max); Time = %.2f\n",
         1.0e-9 * N * N * (N - 1) / t_min, t_min);
  printf("Base version: %.2f GFLOPs (ave); Time = %.2f\n",
         1.0e-9 * N * N * (N - 1) / t_ave, t_ave);

  for (NTrials = 0; NTrials < NTRIALS; ++NTrials) {
    for (i = 0; i < N; i++)
      for (j = 0; j < N; j++)
        cc[j][i] = 0;
    t1 = rtclock();
    pa2_p3_sol(N, &a[0][0], &b[0][0], &cc[0][0], nThreads);
    t2 = rtclock();
    times[NTrials] = t = (t2 - t1);
    printf("Optimized/parallelized version: %.2f GFLOPs; Time = %.2f\n",
           1.0e-9 * N * N * (N - 1) / (t2 - t1), t2 - t1);
  }

  t_ave = 0;
  t_min = INFINITY;
  for (NTrials = 0; NTrials < NTRIALS; ++NTrials) {
    t_ave += times[NTrials];
    t_min = min(t_min, times[NTrials]);
  }
  t_ave /= NTRIALS;

    printf("Optimized/parallelized version (max): %.2f GFLOPs; Time = %.2f\n",
           1.0e-9 * N * N * (N - 1) / t_min, t_min);

    printf("Optimized/parallelized version (ave): %.2f GFLOPs; Time = %.2f\n",
           1.0e-9 * N * N * (N - 1) / t_ave, t_ave);

  compare(N, c, cc);
}

#if !defined(USE_OMP_TIMINGS)
double rtclock(void) {
  struct timezone Tzp;
  struct timeval Tp;
  int stat;
  stat = gettimeofday(&Tp, &Tzp);
  if (stat != 0)
    printf("Error return from gettimeofday: %d", stat);
  return (Tp.tv_sec + Tp.tv_usec * 1.0e-6);
}
#endif

void compare(int n, float wref[][n], float w[][n]) {
  float maxdiff, this_diff;
  int numdiffs;
  int i, j;
  numdiffs = 0;
  maxdiff = 0;
  for (i = 0; i < n; i++)
    for (j = 0; j < n; j++) {
      this_diff = wref[i][j] - w[i][j];
      if (this_diff < 0)
        this_diff = -1.0 * this_diff;
      if (this_diff > threshold) {
        numdiffs++;
        if (this_diff > maxdiff)
          maxdiff = this_diff;
      }
    }
  if (numdiffs > 0)
    printf("%d Diffs found over threshold %f; Max Diff = %f\n", numdiffs,
           threshold, maxdiff);
  else
    printf("Passed Correctness Check\n");
}
