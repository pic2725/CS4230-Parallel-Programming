void pa2_p2_base(int n, float *__restrict__ a, float *__restrict__ b,
                 float *__restrict__ c) {
  int i, j, k;

  for (i = 0; i < n; i++)
    for (j = 0; j < n; j++)
      for (k = 0; k < n; k++)
        c[j * n + i] = c[j * n + i] + a[k * n + j] * b[k * n + i];
}
